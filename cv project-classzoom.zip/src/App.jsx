﻿import { useState, useEffect } from 'react';
import PassageInputPage from './pages/PassageInputPage';
import StudyContainerPage from './pages/StudyContainerPage';
import HomeQuickStart from './components/HomeQuickStart';
import { db } from './utils/firebase';
import { 
  collection, 
  getDocs, 
  addDoc, 
  deleteDoc, 
  doc, 
  query, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import './index.css';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('lingo-theme') || 'light';
  });
  const [passagesList, setPassagesList] = useState([]);
  const [selectedPassage, setSelectedPassage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Apply theme to document element whenever it changes
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // 타임아웃 처리용 유틸리티 (Firebase 응답 지연 시 로컬스토리지 즉시 전환)
  const withTimeout = (promise, ms = 1500) => {
    return Promise.race([
      promise,
      new Promise((_, reject) => setTimeout(() => reject(new Error("Firebase Timeout")), ms))
    ]);
  };

  const fetchPassages = async () => {
    setIsLoading(true);
    try {
      const q = query(collection(db, 'passages'), orderBy('createdAt', 'desc'));
      const querySnapshot = await withTimeout(getDocs(q), 1500);
      const list = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          title: data.title || '제목 없는 지문',
          sentences: data.sentences || [],
          createdAt: data.createdAt ? data.createdAt.toDate() : new Date()
        });
      });
      setPassagesList(list);
      // 로컬스토리지에 최신 백업 저장
      localStorage.setItem('lingo-passages', JSON.stringify(list));
    } catch (error) {
      console.warn("Firestore fetch failed or timed out. Falling back to LocalStorage:", error);
      const localData = JSON.parse(localStorage.getItem('lingo-passages')) || [];
      const parsed = localData.map(item => ({
        ...item,
        createdAt: item.createdAt ? new Date(item.createdAt) : new Date()
      }));
      setPassagesList(parsed);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch passages from Firestore on mount
  useEffect(() => {
    let isMounted = true;
    const loadData = async () => {
      if (isMounted) {
        await fetchPassages();
      }
    };
    loadData();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleThemeChange = (newTheme) => {
    setTheme(newTheme);
    localStorage.setItem('lingo-theme', newTheme);
  };

  const handleSavePassage = async (sentences, title) => {
    setIsLoading(true);
    try {
      await withTimeout(addDoc(collection(db, 'passages'), {
        title,
        sentences,
        createdAt: serverTimestamp()
      }), 1500);
      await fetchPassages();
      setCurrentPage('home');
    } catch (error) {
      console.warn("Firestore save failed or timed out. Saving to LocalStorage:", error);
      const localData = JSON.parse(localStorage.getItem('lingo-passages')) || [];
      const newPassage = {
        id: `local-${Date.now()}`,
        title,
        sentences,
        createdAt: new Date().toISOString()
      };
      const updated = [newPassage, ...localData];
      localStorage.setItem('lingo-passages', JSON.stringify(updated));
      
      const parsed = updated.map(item => ({
        ...item,
        createdAt: new Date(item.createdAt)
      }));
      setPassagesList(parsed);
      setCurrentPage('home');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeletePassage = async (id, e) => {
    e.stopPropagation(); // 카드 클릭 방지
    if (!confirm("정말로 이 지문을 삭제하시겠습니까?")) return;
    
    setIsLoading(true);
    try {
      if (id.startsWith('local-')) {
        throw new Error("Local item bypass");
      }
      await withTimeout(deleteDoc(doc(db, 'passages', id)), 1500);
      await fetchPassages();
    } catch (error) {
      console.warn("Firestore delete failed or local bypass. Removing from LocalStorage:", error);
      const localData = JSON.parse(localStorage.getItem('lingo-passages')) || [];
      const updated = localData.filter(item => item.id !== id);
      localStorage.setItem('lingo-passages', JSON.stringify(updated));
      
      const parsed = updated.map(item => ({
        ...item,
        createdAt: new Date(item.createdAt)
      }));
      setPassagesList(parsed);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPassage = (passage) => {
    setSelectedPassage(passage);
    setCurrentPage('study');
  };

  // Format date helper
  const formatDate = (date) => {
    if (!date) return '';
    return `${date.getFullYear()}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`;
  };

  return (
    <div className="app-container">
      <header style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '32px',
        borderBottom: '4px solid var(--color-border)',
        paddingBottom: '16px'
      }}>
        <h1 style={{ fontSize: '36px', fontWeight: 'bold', letterSpacing: '-1px' }}>
          LingoStar <span style={{ color: 'var(--color-primary)' }}>Vision</span>
        </h1>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <label htmlFor="theme-selector" style={{ fontSize: '20px', fontWeight: 'bold' }}>테마</label>
          <select 
            id="theme-selector"
            value={theme} 
            onChange={(e) => handleThemeChange(e.target.value)}
            style={{ 
              fontSize: '20px', 
              padding: '8px 16px', 
              borderRadius: '8px',
              border: '2px solid var(--color-border)',
              backgroundColor: 'var(--color-bg)',
              color: 'var(--color-text)',
              cursor: 'pointer'
            }}
          >
            <option value="light">밝게 (Light)</option>
            <option value="dark">어둡게 (Dark)</option>
            <option value="yellow">독서용 (Yellow)</option>
            <option value="blue-soft">안구편한 (Blue Soft)</option>
            <option value="high-contrast">고대비 (High Contrast)</option>
          </select>
        </div>
      </header>

      {/* 로딩 인디케이터 (프리미엄 로딩 상태 디자인) */}
      {isLoading && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.4)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 9999,
          backdropFilter: 'blur(4px)'
        }}>
          <div style={{
            backgroundColor: 'var(--color-bg)',
            color: 'var(--color-text)',
            padding: '32px 48px',
            borderRadius: '16px',
            border: '4px solid var(--color-border)',
            textAlign: 'center',
            boxShadow: '0 8px 32px rgba(0,0,0,0.2)'
          }}>
            <div className="spinner" style={{
              width: '64px',
              height: '64px',
              border: '8px solid var(--color-secondary)',
              borderTop: '8px solid var(--color-primary)',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto 16px'
            }} />
            <style>{`
              @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
              }
            `}</style>
            <p style={{ fontSize: '24px', fontWeight: 'bold' }}>데이터 동기화 중...</p>
          </div>
        </div>
      )}

      {/* 1. 홈 대시보드 화면 */}
      {currentPage === 'home' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px', flex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2 style={{ fontSize: '32px', fontWeight: 'bold' }}>나의 학습 지문 목록</h2>
            <button onClick={() => setCurrentPage('input')} style={{ minHeight: '60px' }}>
              + 새 지문 입력하기
            </button>
          </div>

          {passagesList.length === 0 ? (
            /* 빈 대시보드 상태 (Empty State) */
            <div style={{ 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center', 
              justifyContent: 'center', 
              flex: 1, 
              padding: '64px 24px',
              border: '4px dashed var(--color-border)',
              borderRadius: '16px',
              gap: '24px',
              textAlign: 'center'
            }}>
              <span style={{ fontSize: '80px' }}>📖</span>
              <div>
                <h3 style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '8px' }}>저장된 영어 지문이 없습니다</h3>
                <p style={{ fontSize: '20px', color: 'var(--color-text)', opacity: 0.7 }}>새 지문 추가 버튼을 클릭해 첫 영어 지문을 입력해 보세요!</p>
              </div>
              <button onClick={() => setCurrentPage('input')}>
                첫 지문 추가하기
              </button>
            </div>
          ) : (
            /* 지문 목록 대시보드 (Premium Card List Grid) */
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fill, minmax(100%, 1fr))', 
              gap: '20px' 
            }}>
              {passagesList.map((passage) => (
                <div 
                  key={passage.id} 
                  style={{
                    border: '4px solid var(--color-border)',
                    borderRadius: '16px',
                    padding: '24px',
                    backgroundColor: 'var(--color-bg)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '16px',
                    transition: 'transform 0.2s, box-shadow 0.2s',
                    position: 'relative'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <h3 style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '4px', wordBreak: 'break-all' }}>
                        {passage.title}
                      </h3>
                      <p style={{ fontSize: '18px', opacity: 0.6 }}>
                        문장 개수: {passage.sentences.length}개 | 생성일: {formatDate(passage.createdAt)}
                      </p>
                    </div>
                    <button 
                      onClick={(e) => handleDeletePassage(passage.id, e)}
                      style={{ 
                        minWidth: 'auto', 
                        minHeight: '48px', 
                        padding: '0 16px', 
                        fontSize: '18px', 
                        backgroundColor: '#ff4d4d', 
                        color: '#ffffff'
                      }}
                    >
                      삭제
                    </button>
                  </div>

                  {/* 카드 내부 지문 내용 살짝 미리보기 */}
                  <p style={{ 
                    fontSize: '20px', 
                    opacity: 0.8, 
                    display: '-webkit-box', 
                    WebkitLineClamp: 2, 
                    WebkitBoxOrient: 'vertical', 
                    overflow: 'hidden',
                    lineHeight: '1.4',
                    wordBreak: 'keep-all'
                  }}>
                    {passage.sentences.map(s => typeof s === 'string' ? s : (s?.english || '')).join(' ')}
                  </p>

                  <div style={{ display: 'flex', gap: '16px', marginTop: '8px' }}>
                    <button 
                      style={{ flex: 1, minHeight: '72px' }} 
                      onClick={() => handleSelectPassage(passage)}
                    >
                      📖 지문 학습 시작하기 (집중/직독/구조/어휘)
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 2. 새 지문 입력 화면 */}
      {currentPage === 'input' && (
        <PassageInputPage 
          onSave={handleSavePassage} 
          onCancel={() => setCurrentPage('home')} 
        />
      )}

      {/* 3. 통합 지문 상세 학습 화면 */}
      {currentPage === 'study' && selectedPassage && (
        <StudyContainerPage 
          passage={selectedPassage} 
          onBack={() => {
            setSelectedPassage(null);
            setCurrentPage('home');
          }} 
        />
      )}
    </div>
  );
}

export default App;

