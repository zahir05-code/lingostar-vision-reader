import { useState } from 'react';

export default function PassageInputPage({ onSave, onCancel }) {
  const [step, setStep] = useState(1);
  const [text, setText] = useState('');
  const [title, setTitle] = useState('');
  const [sentenceMappings, setSentenceMappings] = useState([]); // { english, korean }[]

  const handleNextStep = () => {
    if (!text.trim()) {
      alert('영어 지문을 입력해 주세요!');
      return;
    }

    // 마침표, 물음표, 느낌표 기준 정밀 문장 분리
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    const cleanedSentences = sentences.map(s => s.trim()).filter(s => s.length > 0);

    if (cleanedSentences.length === 0) {
      alert('분석 가능한 영어 문장이 없습니다. 다시 입력해 주세요.');
      return;
    }

    // 제목 자동 생성 (첫 문장의 앞부분)
    const autoTitle = cleanedSentences[0]
      ? (cleanedSentences[0].length > 30 ? cleanedSentences[0].slice(0, 30) + '...' : cleanedSentences[0])
      : '새로운 지문';
    setTitle(autoTitle);

    // 문장 대칭 매핑 초기 구성
    setSentenceMappings(cleanedSentences.map(english => ({
      english,
      korean: '' // 기본은 비워둠 (사용자 직접 입력 유도)
    })));

    setStep(2);
  };

  const handleKoreanChange = (index, value) => {
    setSentenceMappings(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], korean: value };
      return updated;
    });
  };

  const handleSave = () => {
    // sentenceMappings가 최종 데이터 형태 { english, korean }[]
    onSave(sentenceMappings, title || '새로운 지문');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: '24px', paddingBottom: '48px' }}>
      
      {/* 고대비 단계 표시 헤더 */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ fontSize: '40px', margin: 0, fontWeight: '900' }}>새 지문 추가</h2>
        <div style={{ 
          display: 'flex', 
          gap: '8px', 
          backgroundColor: 'var(--color-secondary)', 
          padding: '8px 16px', 
          borderRadius: '30px',
          border: '3px solid var(--color-border)'
        }}>
          <span style={{ fontSize: '18px', fontWeight: 'bold', color: step === 1 ? 'var(--color-primary)' : 'var(--color-text)' }}>
            1. 영어 본문 입력 {step === 1 ? '🟢' : '✅'}
          </span>
          <span style={{ fontSize: '18px', fontWeight: 'bold', opacity: 0.3 }}>|</span>
          <span style={{ fontSize: '18px', fontWeight: 'bold', color: step === 2 ? 'var(--color-primary)' : 'var(--color-text)' }}>
            2. 한글 직독직해 매핑 {step === 2 ? '🟢' : '⚪'}
          </span>
        </div>
      </div>

      {/* 1단계: 영어 본문 통입력 */}
      {step === 1 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', flex: 1 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', flex: 1 }}>
            <label htmlFor="passage-text" style={{ fontSize: '26px', fontWeight: '900' }}>
              📝 영어 지문 원문 붙여넣기
            </label>
            <p style={{ fontSize: '18px', opacity: 0.7, margin: 0 }}>
              학습할 전체 영어 문단을 아래 창에 복사해서 붙여넣으세요. 다음 단계에서 문장별로 쪼개어 번역을 매핑합니다.
            </p>
            <textarea 
              id="passage-text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Vincent van Gogh's Sunflowers is a very famous painting that shows bright yellow sunflowers in a vase. When I look at it..."
              style={{
                flex: 1,
                fontSize: '28px',
                padding: '24px',
                borderRadius: '16px',
                border: '4px solid var(--color-border)',
                backgroundColor: 'var(--color-bg)',
                color: 'var(--color-text)',
                resize: 'none',
                lineHeight: '1.6'
              }}
            />
          </div>

          <div style={{ display: 'flex', gap: '24px' }}>
            <button 
              onClick={onCancel}
              style={{ 
                flex: 1, 
                backgroundColor: 'var(--color-secondary)', 
                color: 'var(--color-text)',
                minHeight: '76px',
                fontSize: '22px'
              }}
            >
              취소
            </button>
            <button 
              onClick={handleNextStep}
              style={{ 
                flex: 2,
                minHeight: '76px',
                fontSize: '22px'
              }}
            >
              다음: 해석 대칭 매핑하기 ▶
            </button>
          </div>
        </div>
      )}

      {/* 2단계: 문장별 한국어 매핑 */}
      {step === 2 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', flex: 1 }}>
          

          {/* 문장 대칭 다중 매핑 리스트 */}
          <div style={{ 
            flex: 1, 
            display: 'flex', 
            flexDirection: 'column', 
            gap: '24px', 
            overflowY: 'auto', 
            maxHeight: '500px',
            paddingRight: '12px'
          }}>
            <p style={{ fontSize: '20px', fontWeight: 'bold', color: 'var(--color-primary)', margin: 0 }}>
              💡 각 영어 문장 아래에 매핑되는 한국어 직독직해(영어 어순 해설)를 입력하세요.
            </p>

            {sentenceMappings.map((mapping, index) => (
              <div 
                key={index} 
                style={{ 
                  display: 'flex', 
                  flexDirection: 'column', 
                  gap: '12px', 
                  padding: '24px', 
                  border: '4px solid var(--color-border)', 
                  borderRadius: '16px',
                  backgroundColor: 'var(--color-bg)'
                }}
              >
                {/* 영어 원문 라벨 */}
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <span style={{ 
                    backgroundColor: 'var(--color-primary)', 
                    color: 'var(--color-bg)', 
                    padding: '4px 12px', 
                    borderRadius: '8px', 
                    fontWeight: 'bold',
                    fontSize: '18px'
                  }}>
                    문장 {index + 1}
                  </span>
                  <span style={{ fontSize: '18px', opacity: 0.6 }}>English Sentence</span>
                </div>
                
                <p style={{ 
                  fontSize: '24px', 
                  fontWeight: 'bold', 
                  margin: '4px 0 8px 0', 
                  lineHeight: '1.4', 
                  color: 'var(--color-text)' 
                }}>
                  {mapping.english}
                </p>

                {/* 대칭 한국어 입력 textarea */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <label htmlFor={`korean-mapping-${index}`} style={{ fontSize: '18px', fontWeight: 'bold', opacity: 0.8 }}>
                    └ 🎯 직독직해 한글 매핑 번역
                  </label>
                  <textarea 
                    id={`korean-mapping-${index}`}
                    value={mapping.korean}
                    onChange={(e) => handleKoreanChange(index, e.target.value)}
                    placeholder="영어 문장 어순에 맞추어 끊어 읽기 형태로 기재하면 저시력 학생에게 매우 효과적입니다."
                    style={{
                      fontSize: '22px',
                      padding: '16px',
                      borderRadius: '12px',
                      border: '3px solid var(--color-border)',
                      backgroundColor: 'var(--color-secondary)',
                      color: 'var(--color-text)',
                      minHeight: '100px',
                      resize: 'vertical',
                      lineHeight: '1.4'
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* 조작 버튼 */}
          <div style={{ display: 'flex', gap: '24px' }}>
            <button 
              onClick={() => setStep(1)}
              style={{ 
                flex: 1, 
                backgroundColor: 'var(--color-secondary)', 
                color: 'var(--color-text)',
                minHeight: '76px',
                fontSize: '22px',
                border: '3px solid var(--color-border)'
              }}
            >
              ◀ 본문 수정하러 가기
            </button>
            <button 
              onClick={handleSave}
              style={{ 
                flex: 2,
                minHeight: '76px',
                fontSize: '22px',
                boxShadow: '0 8px 24px rgba(0, 102, 204, 0.25)'
              }}
            >
              ✅ LingoStar 지문 최종 저장하기
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
