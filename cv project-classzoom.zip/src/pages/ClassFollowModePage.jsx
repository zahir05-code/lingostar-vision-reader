import { useState, useRef } from 'react';

// 초정밀 풍부한 영한 및 이디엄/숙어 사전 사전 데이터
const dictMock = {
  // 기본 어휘 및 LingoStar 학습 단어
  "essential": "필수적인, 극히 중요한, 본질적인",
  "comprehend": "충분히 이해하다, 파악하다, 깨닫다",
  "accessibility": "접근성, 이용하기 쉬움",
  "focus": "집중하다, 초점, 집중",
  "companion": "동반자, 도우미, 동료, 안내서",
  "brushstrokes": "붓 터치들, 붓질들 (화가의 화법)",
  "brushstroke": "붓 터치, 붓질",
  "bold": "대담한, 선명한, 굵은",
  "colors": "색상들, 색채, 빛깔",
  "color": "색상, 색채",
  "thick": "두꺼운, 굵은, 진한",
  "effectively": "효과적으로, 실질적으로",
  "effective": "효과적인, 유효한",
  
  // 핵심 이디엄, 숙어 및 다중 단어 (Idioms & Collocations)
  "in person": "직접, 몸소, 친히, 실물로",
  "look forward to": "~을 고대하다, 간절히 기다리다",
  "looking forward to": "~을 간절히 고대하는 중이다",
  "visually impaired": "시각 장애가 있는, 저시력의",
  "visually": "시각적으로, 눈으로 보기에",
  "impaired": "손상된, 장애가 있는, 나빠진",
  "assistive technologies": "보조 기술, 보조 기구",
  "assistive": "보조의, 돕는, 지원하는",
  "technologies": "기술들, 과학기술들",
  "accessible to": "~가 접근할 수 있는, 이용할 수 있는",
  
  // 기타 지문 출몰 필수 단어 및 문장 구조 단어들
  "learning": "배움, 학습",
  "low-vision": "저시력의, 약시의",
  "vision": "시력, 시야, 비전, 미래상",
  "reader": "독자, 읽기 도우미, 낭독기",
  "english": "영어, 영국의",
  "passage": "지문, 구절, 통로, 흐름",
  "study": "공부, 학습, 연구, 서재",
  "student": "학생",
  "students": "학생들",
  "class": "수업, 반, 학급, 등급",
  "chunk": "청크, 덩어리, 쪼개다",
  "structure": "구조, 구성, 체계",
  "vocabulary": "어휘, 단어장, 어휘력",
  "pronunciation": "발음, 낭독",
  "native": "원어민의, 토박이의, 타고난",
  "contrast": "대비, 대조, 대비시키다",
  "theme": "테마, 주제, 제목",
  "brightness": "밝기, 조도, 광휘",
  "pinch": "집어넣다, 핀치, 꼬집다, 압박",
  "zoom": "줌, 확대/축소, 급상승하다",
  "important": "중요한, 중대한",
  "difficult": "어려운, 힘든",
  "easy": "쉬운, 수월한, 안락한",
  "artist": "화가, 예술가",
  "used": "사용했다, 익숙한",
  "sunflowers": "해바라기들",
  "sunflower": "해바라기",
  "bright": "밝은, 선명한, 영리한",
  "yellow": "노란색의, 황색의",
  "shows": "보여준다, 전시물",
  "show": "보여주다, 쇼, 전시",
  "impaired learners": "장애를 가진 학습자들",
  "assistive technology": "보조 공학 기술",
  "magnification": "돋보기 확대, 증폭",
  "customization": "개인 맞춤화, 커스터마이징",
  "interventions": "개입들, 조정들, 교육적 중재",
  "intervention": "개입, 조정, 간섭",
  "experience": "경험, 체험하다, 겪다",
  "improved": "개선된, 향상된",
  "improve": "개선하다, 향상시키다",
  "accessible": "접근 가능한, 사용하기 쉬운",
  "provides": "제공한다, 지급한다",
  "provide": "제공하다, 대비하다",
  "fonts": "글꼴들, 폰트들",
  "font": "글꼴, 폰트",
  "fun": "재미있는, 즐거운, 재미",
  "the": "그 (정관사)",
  "and": "그리고, ~와/과",
  "for": "~을 위한, ~동안에",
  "with": "~와 함께, ~을 가진",
  "help": "돕다, 도움, 도우미",
  "helper": "도우미, 조력자",
  "becomes": "~이 된다",
  "become": "~이 되다"
};

// 동적 한국어 뜻 유추 엔진 (어근/접미사 규칙 파서)
const parseDynamicWordMeaning = (word) => {
  const clean = word.toLowerCase().trim();
  
  // 이미 사전에 완벽 매핑이 있으면 그것을 반환
  if (dictMock[clean]) return dictMock[clean];
  
  // 복수형 -s 분석
  if (clean.endsWith('s') && clean.length > 3) {
    const singular = clean.slice(0, -1);
    if (dictMock[singular]) {
      return `${dictMock[singular]} (복수형)`;
    }
  }
  
  // 과거형/형용사형 -ed 분석
  if (clean.endsWith('ed') && clean.length > 4) {
    let base = clean.slice(0, -2);
    if (dictMock[base]) return `${dictMock[base]} (과거/수동형)`;
    if (clean.endsWith('ied')) {
      base = clean.slice(0, -3) + 'y';
      if (dictMock[base]) return `${dictMock[base]} (과거/수동형)`;
    }
  }

  // 부사형 -ly 분석
  if (clean.endsWith('ly') && clean.length > 4) {
    const adj = clean.slice(0, -2);
    if (dictMock[adj]) return `${dictMock[adj]}하게 (부사형)`;
  }
  
  // 진행/명사형 -ing 분석
  if (clean.endsWith('ing') && clean.length > 5) {
    const verb = clean.slice(0, -3);
    if (dictMock[verb]) return `${dictMock[verb]}하는 것/중 (진행/동명사)`;
  }

  // 접두사/접미사 힌트 가이드 결합
  let hint = "";
  if (clean.startsWith('un') || clean.startsWith('in') || clean.startsWith('im')) {
    hint = "[반대/부정의 의미] ";
  } else if (clean.startsWith('re')) {
    hint = "[다시/반복의 의미] ";
  }

  return `${hint}(뜻을 알 수 없음 - 사전 검색 및 단어장 수정 필요)`;
};

export default function ClassFollowModePage({ passages, currentIndex, fontSize = 64, speakText }) {
  // 모달 팝업 상태
  const [selectedWord, setSelectedWord] = useState(null);
  const [meaning, setMeaning] = useState('');
  
  // 터치/클릭 다중 선택 모드 활성화 여부
  const [multiSelectMode, setMultiSelectMode] = useState(false);
  // 다중 선택된 단어들의 인덱스 배열
  const [selectedIndices, setSelectedIndices] = useState([]);
  
  // 드래그 선택 영역 감지를 위한 상태
  const [draggedText, setDraggedText] = useState('');
  const [dragPosition, setDragPosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef(null);

  if (!passages || passages.length === 0) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <p style={{ fontSize: '32px', fontWeight: 'bold' }}>지문이 존재하지 않습니다.</p>
      </div>
    );
  }

  const rawSentenceObj = passages[currentIndex];
  const currentSentence = typeof rawSentenceObj === 'string' ? rawSentenceObj : (rawSentenceObj?.english || '');
  const currentTranslation = typeof rawSentenceObj === 'string' ? '' : (rawSentenceObj?.korean || '');
  const words = currentSentence.split(/\s+/);

  // 마우스/터치 드래그 선택 영역 실시간 탐색 핸들러
  const handleTextSelection = (e) => {
    const selection = window.getSelection();
    if (!selection) return;
    const selectedStr = selection.toString().trim();
    
    // 특수문자 정돈 후 단어가 있는 경우만 처리
    if (selectedStr && selectedStr.length > 1) {
      // 문장 부호 정돈
      const cleanStr = selectedStr.replace(/[.,/#!$%^&*;:{}=\-_`~()?]/g, " ").replace(/\s+/g, " ").trim();
      if (cleanStr) {
        setDraggedText(cleanStr);
        
        // 플로팅 버튼이 표시될 마우스/터치 좌표 계산
        const clientX = e.clientX || (e.changedTouches && e.changedTouches[0].clientX) || 150;
        const clientY = e.clientY || (e.changedTouches && e.changedTouches[0].clientY) || 150;
        
        setDragPosition({
          x: clientX,
          y: clientY - 80 // 드래그 지점 위쪽에 뜨도록 마진 부여
        });
      }
    } else {
      setDraggedText('');
    }
  };

  // 플로팅 드래그 단어 추가 버튼 클릭 핸들러
  const handleAddDraggedText = () => {
    if (!draggedText) return;
    const lower = draggedText.toLowerCase();
    
    // 사전 매핑 또는 동적 유추
    const foundMeaning = dictMock[lower] || parseDynamicWordMeaning(draggedText);
    
    setSelectedWord(draggedText);
    setMeaning(foundMeaning);
    setDraggedText('');
    window.getSelection().removeAllRanges(); // 드래그 영역 해제
  };

  // 단어 클릭 핸들러 (단일 클릭 모드 vs 다중 선택 모드)
  const handleWordClick = (rawWord, index) => {
    // 문장부호 제거
    const cleanWord = rawWord.replace(/[.,/#!$%^&*;:{}=\-_`~()?]/g, "").trim();
    if (!cleanWord) return;

    if (multiSelectMode) {
      // 다중 선택 모드: 선택된 단어 토글
      if (selectedIndices.includes(index)) {
        setSelectedIndices(prev => prev.filter(i => i !== index));
      } else {
        // 순서 상관없이 정렬하여 자연스러운 구(phrase)가 이루어지도록 함
        setSelectedIndices(prev => [...prev, index].sort((a, b) => a - b));
      }
    } else {
      // 단일 클릭 모드: 기존 팝업 오픈
      const lower = cleanWord.toLowerCase();
      const foundMeaning = dictMock[lower] || parseDynamicWordMeaning(cleanWord);
      
      setSelectedWord(cleanWord);
      setMeaning(foundMeaning);
    }
  };

  // 선택된 다중 단어들 조합해서 이디엄으로 띄우기
  const handleViewMultiSelectMeaning = () => {
    if (selectedIndices.length === 0) return;
    
    // 선택된 인덱스들의 원본 단어를 공백으로 병합
    const combinedPhrase = selectedIndices.map(i => words[i].replace(/[.,/#!$%^&*;:{}=\-_`~()?]/g, "").trim()).join(' ');
    const lower = combinedPhrase.toLowerCase();
    
    // 사전 매칭 또는 동적 유추
    const foundMeaning = dictMock[lower] || parseDynamicWordMeaning(combinedPhrase);
    
    setSelectedWord(combinedPhrase);
    setMeaning(foundMeaning);
  };

  // 나만의 단어장에 최종 저장
  const handleSaveToVocab = () => {
    if (!selectedWord) return;
    const currentVocab = JSON.parse(localStorage.getItem('lingo-my-vocab')) || [];
    
    // 이미 등록되어 있는지 확인 (대소문자 무관)
    if (!currentVocab.some(item => item.word.toLowerCase() === selectedWord.toLowerCase())) {
      const updated = [...currentVocab, { 
        word: selectedWord, 
        meaning: meaning,
        sentence: currentSentence,
        addedAt: new Date().toISOString() 
      }];
      localStorage.setItem('lingo-my-vocab', JSON.stringify(updated));
      alert(`⭐ 단어 및 숙어장에 완벽히 추가되었습니다:\n[${selectedWord}]`);
    } else {
      alert(`이미 등록된 단어/숙어입니다:\n[${selectedWord}]`);
    }
    
    // 초기화
    setSelectedWord(null);
    setSelectedIndices([]);
    setDraggedText('');
  };

  return (
    <div 
      ref={containerRef}
      onMouseUp={handleTextSelection}
      onTouchEnd={handleTextSelection}
      style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: '24px',
        padding: '32px 24px',
        border: '6px solid var(--color-border)',
        borderRadius: '24px',
        backgroundColor: 'var(--color-bg)',
        boxShadow: '0 8px 32px rgba(0,0,0,0.05)',
        minHeight: '350px',
        justifyContent: 'center',
        position: 'relative'
      }}
    >
      {/* 플로팅 드래그 추가 툴팁 */}
      {draggedText && (
        <button
          onClick={handleAddDraggedText}
          style={{
            position: 'fixed',
            left: `${dragPosition.x}px`,
            top: `${dragPosition.y}px`,
            zIndex: 999,
            backgroundColor: 'var(--color-primary)',
            color: 'var(--color-bg)',
            border: '3px solid var(--color-border)',
            borderRadius: '30px',
            padding: '12px 24px',
            fontSize: '18px',
            fontWeight: 'bold',
            boxShadow: '0 8px 24px rgba(0,0,0,0.2)',
            cursor: 'pointer',
            whiteSpace: 'nowrap',
            animation: 'fadeIn 0.2s ease-out'
          }}
        >
          ➕ [선택 영역 추가] "{draggedText.length > 15 ? draggedText.slice(0, 15) + '...' : draggedText}"
        </button>
      )}

      {/* 상단 조작바 (TTS 낭독 & 숙어 다중선택 토글) */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        flexWrap: 'wrap',
        gap: '16px',
        borderBottom: '3px solid var(--color-border)',
        paddingBottom: '16px'
      }}>
        {/* TTS 낭독 */}
        <button
          onClick={() => speakText(currentSentence)}
          style={{
            minHeight: '64px',
            minWidth: '220px',
            fontSize: '22px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '12px',
            borderRadius: '16px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
          }}
        >
          🔊 원어민 낭독 (TTS)
        </button>

        {/* 다중 단어 선택 토글 버튼 */}
        <button
          onClick={() => {
            setMultiSelectMode(!multiSelectMode);
            setSelectedIndices([]); // 선택 인덱스 초기화
          }}
          style={{
            minHeight: '64px',
            minWidth: '280px',
            fontSize: '22px',
            backgroundColor: multiSelectMode ? 'var(--color-primary)' : 'var(--color-secondary)',
            color: multiSelectMode ? 'var(--color-bg)' : 'var(--color-text)',
            border: '3px solid var(--color-border)',
            borderRadius: '16px',
            fontWeight: 'bold',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px'
          }}
        >
          {multiSelectMode ? '🔘 숙어 선택 모드: [켜짐]' : '⚪ 숙어 다중선택 모드'}
        </button>
      </div>

      {/* 다중 선택 진행 힌트 패널 */}
      {multiSelectMode && (
        <div style={{
          padding: '16px 24px',
          backgroundColor: 'var(--color-secondary)',
          borderRadius: '16px',
          border: '3px dashed var(--color-primary)',
          textAlign: 'center',
          display: 'flex',
          flexDirection: 'column',
          gap: '12px'
        }}>
          <p style={{ fontSize: '20px', fontWeight: 'bold', color: 'var(--color-text)' }}>
            💡 [숙어 선택] 본문의 단어를 순서대로 터치하여 숙어나 이디엄 덩어리를 만드세요!
          </p>
          {selectedIndices.length > 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
              <div style={{ 
                fontSize: '24px', 
                fontWeight: '900', 
                color: 'var(--color-primary)', 
                backgroundColor: 'var(--color-bg)',
                padding: '8px 20px',
                borderRadius: '8px',
                border: '2px solid var(--color-border)'
              }}>
                조합된 단어: {selectedIndices.map(i => words[i].replace(/[.,/#!$%^&*;:{}=\-_`~()?]/g, "").trim()).join(' ')}
              </div>
              <div style={{ display: 'flex', gap: '12px' }}>
                <button
                  onClick={handleViewMultiSelectMeaning}
                  style={{
                    minWidth: '180px',
                    minHeight: '54px',
                    fontSize: '18px',
                    backgroundColor: 'var(--color-primary)',
                    color: 'var(--color-bg)'
                  }}
                >
                  🔍 숙어 뜻 확인
                </button>
                <button
                  onClick={() => setSelectedIndices([])}
                  style={{
                    minWidth: '100px',
                    minHeight: '54px',
                    fontSize: '18px',
                    backgroundColor: 'var(--color-bg)',
                    color: 'var(--color-text)',
                    border: '2px solid var(--color-border)'
                  }}
                >
                  초기화
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 개별 단어 단위로 클릭 가능한 문장 영역 */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center',
        gap: '12px 16px',
        lineHeight: '2.0',
        padding: '24px 16px',
        userSelect: 'text' // 드래그 텍스트 활성화
      }}>
        {words.map((w, index) => {
          const isSelected = selectedIndices.includes(index);
          return (
            <span
              key={index}
              onClick={() => handleWordClick(w, index)}
              style={{
                fontSize: `${fontSize}px`,
                fontWeight: '900',
                cursor: 'pointer',
                padding: '4px 12px',
                borderRadius: '12px',
                transition: 'all 0.2s',
                borderBottom: isSelected ? '6px solid var(--color-primary)' : '4px dashed var(--color-border)',
                backgroundColor: isSelected ? 'rgba(0, 102, 204, 0.15)' : 'transparent',
                color: isSelected ? 'var(--color-primary)' : 'var(--color-text)',
                display: 'inline-block',
                userSelect: 'text'
              }}
              onMouseEnter={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.backgroundColor = 'var(--color-secondary)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
            >
              {w}
            </span>
          );
        })}
      </div>

      {/* 실시간 매핑 직독직해 한글 본문 */}
      {currentTranslation && (
        <div style={{
          marginTop: '16px',
          padding: '24px',
          borderRadius: '20px',
          backgroundColor: 'var(--color-secondary)',
          border: '4px solid var(--color-primary)',
          boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.05)',
          animation: 'fadeIn 0.3s ease-out'
        }}>
          <p style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: 'var(--color-primary)',
            margin: '0 0 12px 0',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            🎯 직독직해 매핑 번역 (Korean Translation)
          </p>
          <p style={{
            fontSize: `${Math.max(fontSize * 0.75, 24)}px`,
            fontWeight: '800',
            lineHeight: '1.6',
            color: 'var(--color-text)',
            margin: 0
          }}>
            {currentTranslation}
          </p>
        </div>
      )}

      {/* 단어/숙어 간이 사전 팝업 모달 */}
      {selectedWord && (
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          backgroundColor: 'var(--color-bg)',
          border: '5px solid var(--color-primary)',
          borderRadius: '24px',
          padding: '32px',
          boxShadow: '0 12px 48px rgba(0,0,0,0.25)',
          zIndex: 1000,
          width: '90%',
          maxWidth: '550px',
          display: 'flex',
          flexDirection: 'column',
          gap: '24px',
          textAlign: 'center',
          animation: 'fadeIn 0.2s ease-out'
        }}>
          <div>
            <span style={{ 
              fontSize: '18px', 
              fontWeight: 'bold', 
              color: 'var(--color-text)', 
              opacity: 0.6,
              border: '2px solid var(--color-border)',
              padding: '4px 12px',
              borderRadius: '20px',
              backgroundColor: 'var(--color-secondary)'
            }}>
              {selectedWord.includes(' ') ? '📝 이디엄 / 숙어' : '📒 단어'}
            </span>
            <h3 style={{ fontSize: '38px', fontWeight: '900', color: 'var(--color-primary)', marginTop: '16px', wordBreak: 'break-all' }}>
              {selectedWord}
            </h3>
            <div style={{ 
              fontSize: '28px', 
              fontWeight: 'bold', 
              marginTop: '16px',
              padding: '16px',
              backgroundColor: 'var(--color-secondary)',
              borderRadius: '12px',
              border: '2px solid var(--color-border)',
              lineHeight: '1.4'
            }}>
              뜻: {meaning}
            </div>
          </div>

          <div style={{ display: 'flex', gap: '16px' }}>
            <button
              onClick={handleSaveToVocab}
              style={{
                flex: 2,
                minHeight: '72px',
                fontSize: '22px',
                borderRadius: '16px'
              }}
            >
              ⭐ 단어장 추가
            </button>
            <button
              onClick={() => setSelectedWord(null)}
              style={{
                flex: 1,
                minHeight: '72px',
                fontSize: '22px',
                backgroundColor: 'var(--color-secondary)',
                color: 'var(--color-text)',
                border: '3px solid var(--color-border)',
                borderRadius: '16px'
              }}
            >
              닫기
            </button>
          </div>
        </div>
      )}

      {/* 스타일 애니메이션 주입 */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translate(-50%, -48%) scale(0.95); }
          to { opacity: 1; transform: translate(-50%, -50%) scale(1); }
        }
      `}</style>
    </div>
  );
}
