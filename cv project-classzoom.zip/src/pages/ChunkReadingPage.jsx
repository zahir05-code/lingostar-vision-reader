export default function ChunkReadingPage({ passages, currentIndex, fontSize = 48, speakText }) {
  if (!passages || passages.length === 0) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <p style={{ fontSize: '32px', fontWeight: 'bold' }}>지문이 존재하지 않습니다.</p>
      </div>
    );
  }

  // 간단한 청크 분리 로직 (콤마, 접속사 앞, 전치사 앞 등 간단한 규칙 적용)
  const splitIntoChunks = (sentence) => {
    const regex = /(.*?)(,| that | which | who | and | but | because | however )/gi;
    let chunks = [];
    let match;
    let lastIndex = 0;
    
    while ((match = regex.exec(sentence)) !== null) {
      chunks.push(match[0].trim());
      lastIndex = regex.lastIndex;
    }
    
    const remaining = sentence.slice(lastIndex).trim();
    if (remaining) {
      chunks.push(remaining);
    }
    
    if (chunks.length <= 1) {
      const words = sentence.split(' ');
      const mid = Math.ceil(words.length / 2);
      if (words.length > 4) {
        return [words.slice(0, mid).join(' '), words.slice(mid).join(' ')];
      }
      return [sentence];
    }
    
    return chunks;
  };

  const rawSentenceObj = passages[currentIndex];
  const currentSentence = typeof rawSentenceObj === 'string' ? rawSentenceObj : (rawSentenceObj?.english || '');
  const currentTranslation = typeof rawSentenceObj === 'string' ? '' : (rawSentenceObj?.korean || '');
  const chunks = splitIntoChunks(currentSentence);

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      gap: '20px',
      overflowY: 'auto',
      height: '100%'
    }}>
      {/* 상단 문장 전체 듣기 제어 버튼 */}
      <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center' }}>
        <p style={{ fontSize: '20px', opacity: 0.6, margin: 0 }}>의미 단위(청크)로 수직 배열해 시야 피로를 낮췄습니다.</p>
        <button
          onClick={() => speakText(currentSentence)}
          style={{
            minHeight: '60px',
            fontSize: '18px',
            borderRadius: '16px',
            padding: '0 20px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
        >
          🔊 문장 전체 낭독
        </button>
      </div>

      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: '24px'
      }}>
        {chunks.map((chunk, idx) => (
          <div key={idx} style={{
            padding: '24px 28px',
            border: '4px solid var(--color-border)',
            borderRadius: '16px',
            backgroundColor: 'var(--color-bg)',
            boxShadow: '0 4px 16px rgba(0,0,0,0.03)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '24px'
          }}>
            <p style={{
              fontSize: `${fontSize}px`,
              fontWeight: 'bold',
              lineHeight: '1.4',
              wordBreak: 'keep-all',
              flex: 1
            }}>
              {chunk}
            </p>
            
            {/* 개별 청크 듣기 버튼 */}
            <button
              onClick={() => speakText(chunk)}
              style={{
                minWidth: '64px',
                minHeight: '64px',
                fontSize: '24px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: 'var(--color-secondary)',
                color: 'var(--color-text)',
                border: '3px solid var(--color-border)'
              }}
              title="이 구절 듣기"
            >
              🔊
            </button>
          </div>
        ))}

        {currentTranslation && (
          <div style={{
            padding: '24px',
            border: '4px solid var(--color-primary)',
            borderRadius: '16px',
            backgroundColor: 'var(--color-secondary)',
            boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.05)',
            marginTop: '8px'
          }}>
            <p style={{
              fontSize: '18px',
              fontWeight: 'bold',
              color: 'var(--color-primary)',
              margin: '0 0 8px 0'
            }}>
              🎯 직독직해 매핑 번역
            </p>
            <p style={{
              fontSize: `${Math.max(fontSize * 0.75, 24)}px`,
              fontWeight: '800',
              lineHeight: '1.5',
              color: 'var(--color-text)',
              margin: 0
            }}>
              {currentTranslation}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
