import { useState } from 'react';

// 문장을 의미 단위로 끊어주는 헬퍼 함수
const parseSlashSentence = (sentence) => {
  const clean = sentence.trim();
  if (!clean) return "";
  
  const words = clean.split(' ');
  const result = [];
  let currentChunk = [];
  
  // 끊어 읽기 좋은 지점(접속사, 전치사, 관계사, 동사 등)
  const cutWords = [
    'although', 'when', 'if', 'because', 'after', 'before', 'since', 'while',
    'with', 'of', 'to', 'in', 'for', 'at', 'by', 'on', 'about', 'from', 'into', 'through',
    'that', 'which', 'who', 'whom', 'whose', 'where', 'why', 'how',
    'and', 'but', 'or', 'so', 'yet',
    'is', 'are', 'was', 'were', 'am',
    'does', 'do', 'did', 'has', 'have', 'had',
    'can', 'could', 'will', 'would', 'shall', 'should', 'may', 'might', 'must'
  ];

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const lower = word.toLowerCase().replace(/[^a-z]/g, '');
    
    if (i > 0 && cutWords.includes(lower)) {
      if (currentChunk.length > 0) {
        result.push(currentChunk.join(' '));
      }
      currentChunk = [word];
    } else {
      currentChunk.push(word);
    }
  }
  if (currentChunk.length > 0) {
    result.push(currentChunk.join(' '));
  }
  
  return result.join(' / ');
};


export default function ParagraphStructurePage({ sentences, fontSize = 32, speakText }) {
  const [openTrees, setOpenTrees] = useState({});
  const [userSummaries, setUserSummaries] = useState({
    intro: '',
    body: '',
    conclusion: ''
  });

  if (!sentences || sentences.length === 0) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
        <p style={{ fontSize: `${fontSize}px`, fontWeight: 'bold' }}>지문 데이터가 존재하지 않습니다.</p>
      </div>
    );
  }

  const toggleTree = (index) => {
    setOpenTrees(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  // 도입 / 본론 / 결론 삼분할 매핑
  const total = sentences.length;
  const introEnd = Math.max(1, Math.floor(total * 0.25));
  const bodyEnd = Math.max(introEnd + 1, Math.floor(total * 0.8));

  const introSentences = sentences.slice(0, introEnd);
  const bodySentences = sentences.slice(introEnd, bodyEnd);
  const conclusionSentences = sentences.slice(bodyEnd);

  const extractText = (sList) => {
    return sList.map(s => typeof s === 'string' ? s : (s?.english || '')).join(' ');
  };

  const introText = extractText(introSentences);
  const bodyText = extractText(bodySentences);
  const conclusionText = extractText(conclusionSentences);

  const modelSummaries = {
    intro: "글의 핵심 화두(시각 장애 극복 및 예술/학습의 긍정적 효과)를 던지는 도입부입니다.",
    body: "학습자들이 보조 동료/조력자와 함께 공부하며 난관을 헤쳐나가는 중심 본론부입니다.",
    conclusion: "세상을 모두에게 공평하고 접근 가능하게 만드는 기술의 궁극적 가치를 역설하는 결론부입니다."
  };

  const handleSummaryChange = (section, value) => {
    setUserSummaries(prev => ({
      ...prev,
      [section]: value
    }));
  };

  const sectionStyle = (borderColor) => ({
    borderLeft: `14px solid ${borderColor}`,
    padding: '28px',
    marginBottom: '48px',
    backgroundColor: 'var(--color-bg)',
    borderRadius: '0 24px 24px 0',
    boxShadow: '0 8px 32px rgba(0,0,0,0.06)',
    border: '4px solid var(--color-border)',
    borderLeftWidth: '14px'
  });

  const headerStyle = (color) => ({
    fontSize: '30px',
    fontWeight: '900',
    color: color,
    marginBottom: '20px',
    display: 'flex',
    alignItems: 'center',
    gap: '12px'
  });

  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      gap: '32px', 
      overflowY: 'auto', 
      height: '100%',
      paddingBottom: '64px'
    }}>
      {/* 타이틀 및 저시력 학습 차별화 가이드 */}
      <div style={{ 
        textAlign: 'center', 
        marginBottom: '16px',
        padding: '24px',
        border: '4px solid var(--color-border)',
        borderRadius: '24px',
        backgroundColor: 'var(--color-secondary)'
      }}>
        <h3 style={{ fontSize: '34px', fontWeight: '900', color: 'var(--color-primary)' }}>
          🧱 구조 처리 속도 배가 훈련 (수능·내신 상위권 비결)
        </h3>
        <p style={{ fontSize: '20px', opacity: 0.8, marginTop: '12px', lineHeight: '1.6' }}>
          저시력 수험생이 영어를 빠르게 읽기 위해선 <strong>"수직 의존성 트리"</strong> 분석을 통해 주어·동사 핵심 골격과 수식절을 한눈에 끊어 읽는 <strong>'하향식 구조화 속도'</strong>가 절대적으로 중요합니다.
        </p>
      </div>

      {/* 문장 카드 및 수직 트리 토글 컴포넌트 렌더러 */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <h4 style={{ fontSize: '24px', fontWeight: 'bold', borderBottom: '3px solid var(--color-border)', paddingBottom: '8px' }}>
          🌲 지문 문장별 수직 의존성 트리 분석 훈련기
        </h4>
        
        {sentences.map((sentObj, index) => {
          const sent = typeof sentObj === 'string' ? sentObj : (sentObj?.english || '');
          const slashText = parseSlashSentence(sent);
          const isOpen = openTrees[index];
          return (
            <div 
              key={index}
              style={{
                border: '4px solid var(--color-border)',
                borderRadius: '20px',
                padding: '24px',
                backgroundColor: 'var(--color-bg)',
                display: 'flex',
                flexDirection: 'column',
                gap: '16px'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px' }}>
                <p style={{ 
                  fontSize: `${fontSize}px`, 
                  fontWeight: 'bold',
                  lineHeight: '1.5',
                  color: 'var(--color-text)',
                  flex: 1
                }}>
                  <span style={{ color: 'var(--color-primary)', marginRight: '12px' }}>[{index + 1}]</span>
                  {sent}
                </p>
                <button
                  onClick={() => toggleTree(index)}
                  style={{
                    padding: '12px 20px',
                    fontSize: '18px',
                    fontWeight: '900',
                    backgroundColor: isOpen ? 'var(--color-primary)' : 'var(--color-secondary)',
                    color: isOpen ? 'white' : 'var(--color-text)',
                    border: '3px solid var(--color-border)',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    whiteSpace: 'nowrap'
                  }}
                >
                  {isOpen ? '🌲 닫기 🔼' : '🌲 구조 분석 🔽'}
                </button>
              </div>

              {/* 🌲 심플 문장 성분 분할 영역 */}
              {isOpen && (
                <div style={{
                  border: '4px solid var(--color-border)',
                  borderRadius: '16px',
                  padding: '24px',
                  backgroundColor: 'var(--color-secondary)',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '16px',
                  animation: 'fadeIn 0.2s ease'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '2px solid var(--color-border)', paddingBottom: '12px' }}>
                    <span style={{ fontSize: '20px', fontWeight: '900', color: 'var(--color-primary)' }}>
                      🔍 의미 단위 문장 성분 분할
                    </span>
                    <button
                      onClick={() => speakText(slashText)}
                      style={{
                        padding: '8px 16px',
                        fontSize: '18px',
                        fontWeight: 'bold',
                        backgroundColor: 'var(--color-bg)',
                        border: '2px solid var(--color-border)',
                        borderRadius: '8px',
                        cursor: 'pointer'
                      }}
                    >
                      🔊 분할 문장 듣기
                    </button>
                  </div>

                  <div style={{ 
                    fontSize: `${fontSize * 0.9}px`, 
                    lineHeight: '2', 
                    fontWeight: 'bold',
                    color: 'var(--color-text)'
                  }}>
                    {slashText.split(' / ').map((chunk, i, arr) => (
                      <span key={i}>
                        {chunk}
                        {i < arr.length - 1 && (
                          <span style={{ color: 'var(--color-primary)', margin: '0 8px', fontWeight: '900' }}>/</span>
                        )}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: '24px', borderTop: '4px solid var(--color-border)', paddingTop: '32px' }}>
        <h4 style={{ fontSize: '26px', fontWeight: '900', marginBottom: '24px', textAlign: 'center' }}>
          📑 논리 단락 삼분할 구조 및 핵심 요약 훈련
        </h4>
      </div>

      {/* 1. 도입 (Introduction) */}
      <div style={sectionStyle('#2196f3')}>
        <div style={headerStyle('#2196f3')}>
          <span style={{ fontSize: '36px' }}>🔵</span>
          <span>도입 (Introduction)</span>
        </div>
        <p style={{ 
          fontSize: `${fontSize}px`, 
          lineHeight: '1.6', 
          marginBottom: '24px',
          fontWeight: '500',
          wordBreak: 'keep-all'
        }}>
          {introText}
        </p>
        
        {/* 요약 박스 */}
        <div style={{ 
          backgroundColor: 'var(--color-secondary)', 
          padding: '20px', 
          borderRadius: '12px',
          border: '2px dashed var(--color-border)'
        }}>
          <h4 style={{ fontSize: '22px', fontWeight: 'bold', marginBottom: '12px' }}>💡 도입부 한 줄 요약 연습</h4>
          <textarea
            value={userSummaries.intro}
            onChange={(e) => handleSummaryChange('intro', e.target.value)}
            placeholder="여기에 도입부 내용을 한 문장으로 요약해 보세요..."
            style={{
              width: '100%',
              minHeight: '80px',
              fontSize: '20px',
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid var(--color-border)',
              backgroundColor: 'var(--color-bg)',
              color: 'var(--color-text)',
              marginBottom: '12px',
              resize: 'vertical'
            }}
          />
          <details style={{ cursor: 'pointer' }}>
            <summary style={{ fontSize: '20px', fontWeight: 'bold', color: 'var(--color-primary)' }}>
              모범 가이드 보기
            </summary>
            <p style={{ fontSize: '20px', marginTop: '12px', lineHeight: '1.5', opacity: 0.8 }}>
              {modelSummaries.intro}
            </p>
          </details>
        </div>
      </div>

      {/* 2. 본론 (Body) */}
      <div style={sectionStyle('#fbc02d')}>
        <div style={headerStyle('#fbc02d')}>
          <span style={{ fontSize: '36px' }}>🟡</span>
          <span>본론 (Body)</span>
        </div>
        <p style={{ 
          fontSize: `${fontSize}px`, 
          lineHeight: '1.6', 
          marginBottom: '24px',
          fontWeight: '500',
          wordBreak: 'keep-all'
        }}>
          {bodyText}
        </p>

        {/* 요약 박스 */}
        <div style={{ 
          backgroundColor: 'var(--color-secondary)', 
          padding: '20px', 
          borderRadius: '12px',
          border: '2px dashed var(--color-border)'
        }}>
          <h4 style={{ fontSize: '22px', fontWeight: 'bold', marginBottom: '12px' }}>💡 본론부 한 줄 요약 연습</h4>
          <textarea
            value={userSummaries.body}
            onChange={(e) => handleSummaryChange('body', e.target.value)}
            placeholder="여기에 본론부 내용을 한 문장으로 요약해 보세요..."
            style={{
              width: '100%',
              minHeight: '80px',
              fontSize: '20px',
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid var(--color-border)',
              backgroundColor: 'var(--color-bg)',
              color: 'var(--color-text)',
              marginBottom: '12px',
              resize: 'vertical'
            }}
          />
          <details style={{ cursor: 'pointer' }}>
            <summary style={{ fontSize: '20px', fontWeight: 'bold', color: 'var(--color-primary)' }}>
              모범 가이드 보기
            </summary>
            <p style={{ fontSize: '20px', marginTop: '12px', lineHeight: '1.5', opacity: 0.8 }}>
              {modelSummaries.body}
            </p>
          </details>
        </div>
      </div>

      {/* 3. 결론 (Conclusion) */}
      <div style={sectionStyle('#e65100')}>
        <div style={headerStyle('#e65100')}>
          <span style={{ fontSize: '36px' }}>🟠</span>
          <span>결론 (Conclusion)</span>
        </div>
        <p style={{ 
          fontSize: `${fontSize}px`, 
          lineHeight: '1.6', 
          marginBottom: '24px',
          fontWeight: '500',
          wordBreak: 'keep-all'
        }}>
          {conclusionText}
        </p>

        {/* 요약 박스 */}
        <div style={{ 
          backgroundColor: 'var(--color-secondary)', 
          padding: '20px', 
          borderRadius: '12px',
          border: '2px dashed var(--color-border)'
        }}>
          <h4 style={{ fontSize: '22px', fontWeight: 'bold', marginBottom: '12px' }}>💡 결론부 한 줄 요약 연습</h4>
          <textarea
            value={userSummaries.conclusion}
            onChange={(e) => handleSummaryChange('conclusion', e.target.value)}
            placeholder="여기에 결론부 내용을 한 문장으로 요약해 보세요..."
            style={{
              width: '100%',
              minHeight: '80px',
              fontSize: '20px',
              padding: '12px',
              borderRadius: '8px',
              border: '2px solid var(--color-border)',
              backgroundColor: 'var(--color-bg)',
              color: 'var(--color-text)',
              marginBottom: '12px',
              resize: 'vertical'
            }}
          />
          <details style={{ cursor: 'pointer' }}>
            <summary style={{ fontSize: '20px', fontWeight: 'bold', color: 'var(--color-primary)' }}>
              모범 가이드 보기
            </summary>
            <p style={{ fontSize: '20px', marginTop: '12px', lineHeight: '1.5', opacity: 0.8 }}>
              {modelSummaries.conclusion}
            </p>
          </details>
        </div>
      </div>
      
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
