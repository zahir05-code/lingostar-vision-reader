import { useState } from 'react';

// 초정밀 풍부한 영한 및 이디엄/숙어 사전 사전 데이터 (ClassFollowModePage와 동기화)
const dictMock = {
  "essential": "필수적인, 극히 중요한, 본질적인",
  "comprehend": "충분히 이해하다, 파악하다, 깨닫다",
  "accessibility": "접근성, 이용하기 쉬움",
  "focus": "집중하다, 초점, 집중",
  "companion": "동반자, 도우미, 동료, 안내서",
  "brushstrokes": "붓 터치들, 붓질들 (화가의 화법)",
  "brushstroke": "붓 터치, 붓질",
  "bold": "대담한, 선명한, 굵은",
  "colors": "색상들, 색채, 빛깔",
  "color": "색상, 색채",
  "thick": "두꺼운, 굵은, 진한",
  "effectively": "효과적으로, 실질적으로",
  "effective": "효과적인, 유효한",
  
  "in person": "직접, 몸소, 친히, 실물로",
  "look forward to": "~을 고대하다, 간절히 기다리다",
  "looking forward to": "~을 간절히 고대하는 중이다",
  "visually impaired": "시각 장애가 있는, 저시력의",
  "visually": "시각적으로, 눈으로 보기에",
  "impaired": "손상된, 장애가 있는, 나빠진",
  "assistive technologies": "보조 기술, 보조 기구",
  "assistive": "보조의, 돕는, 지원하는",
  "technologies": "기술들, 과학기술들",
  "accessible to": "~가 접근할 수 있는, 이용할 수 있는",
  
  "learning": "배움, 학습",
  "low-vision": "저시력의, 약시의",
  "vision": "시력, 시야, 비전, 미래상",
  "reader": "독자, 읽기 도우미, 낭독기",
  "english": "영어, 영국의",
  "passage": "지문, 구절, 통로, 흐름",
  "study": "공부, 학습, 연구, 서재",
  "student": "학생",
  "students": "학생들",
  "class": "수업, 반, 학급, 등급",
  "chunk": "청크, 덩어리, 쪼개다",
  "structure": "구조, 구성, 체계",
  "vocabulary": "어휘, 단어장, 어휘력",
  "pronunciation": "발음, 낭독",
  "native": "원어민의, 토박이의, 타고난",
  "contrast": "대비, 대조, 대비시키다",
  "theme": "테마, 주제, 제목",
  "brightness": "밝기, 조도, 광휘",
  "pinch": "집어넣다, 핀치, 꼬집다, 압박",
  "zoom": "줌, 확대/축소, 급상승하다",
  "important": "중요한, 중대한",
  "difficult": "어려운, 힘든",
  "easy": "쉬운, 수월한, 안락한",
  "artist": "화가, 예술가",
  "used": "사용했다, 익숙한",
  "sunflowers": "해바라기들",
  "sunflower": "해바라기",
  "bright": "밝은, 선명한, 영리한",
  "yellow": "노란색의, 황색의",
  "shows": "보여준다, 전시물",
  "show": "보여주다, 쇼, 전시",
  "impaired learners": "장애를 가진 학습자들",
  "assistive technology": "보조 공학 기술",
  "magnification": "돋보기 확대, 증폭",
  "customization": "개인 맞춤화, 커스터마이징",
  "interventions": "개입들, 조정들, 교육적 중재",
  "intervention": "개입, 조정, 간섭",
  "experience": "경험, 체험하다, 겪다",
  "improved": "개선된, 향상된",
  "improve": "개선하다, 향상시키다",
  "accessible": "접근 가능한, 사용하기 쉬운",
  "provides": "제공한다, 지급한다",
  "provide": "제공하다, 대비하다",
  "fonts": "글꼴들, 폰트들",
  "font": "글꼴, 폰트",
  "fun": "재미있는, 즐거운, 재미",
  "the": "그 (정관사)",
  "and": "그리고, ~와/과",
  "for": "~을 위한, ~동안에",
  "with": "~와 함께, ~을 가진",
  "help": "돕다, 도움, 도우미",
  "helper": "도우미, 조력자",
  "becomes": "~이 된다",
  "become": "~이 되다"
};

// 동적 한국어 뜻 유추 파서
const parseDynamicWordMeaning = (word) => {
  const clean = word.toLowerCase().trim();
  if (dictMock[clean]) return dictMock[clean];
  
  if (clean.endsWith('s') && clean.length > 3) {
    const singular = clean.slice(0, -1);
    if (dictMock[singular]) return `${dictMock[singular]} (복수형)`;
  }
  
  if (clean.endsWith('ed') && clean.length > 4) {
    let base = clean.slice(0, -2);
    if (dictMock[base]) return `${dictMock[base]} (과거/수동형)`;
    if (clean.endsWith('ied')) {
      base = clean.slice(0, -3) + 'y';
      if (dictMock[base]) return `${dictMock[base]} (과거/수동형)`;
    }
  }

  if (clean.endsWith('ly') && clean.length > 4) {
    const adj = clean.slice(0, -2);
    if (dictMock[adj]) return `${dictMock[adj]}하게 (부사형)`;
  }
  
  if (clean.endsWith('ing') && clean.length > 5) {
    const verb = clean.slice(0, -3);
    if (dictMock[verb]) return `${dictMock[verb]}하는 것/중 (진행/동명사)`;
  }

  let hint = "";
  if (clean.startsWith('un') || clean.startsWith('in') || clean.startsWith('im')) {
    hint = "[반대/부정의 의미] ";
  } else if (clean.startsWith('re')) {
    hint = "[다시/반복의 의미] ";
  }

  return `${hint}(뜻을 알 수 없음 - 사전 검색 및 단어장 수정 필요)`;
};

export default function VocabularyPage({ fontSize = 32, speakText }) {
  // 모범 단어 데이터 사전 정의
  const defaultWords = [
    {
      word: "essential",
      partOfSpeech: "adj.",
      meaning: "필수적인, 극히 중요한, 본질적인",
      synonyms: ["crucial", "vital", "necessary", "indispensable"],
      antonyms: ["unnecessary", "optional", "trivial", "secondary"]
    },
    {
      word: "comprehend",
      partOfSpeech: "v.",
      meaning: "충분히 이해하다, 파악하다, 깨닫다",
      synonyms: ["understand", "grasp", "apprehend", "realize"],
      antonyms: ["misunderstand", "misinterpret", "ignore"]
    },
    {
      word: "accessibility",
      partOfSpeech: "n.",
      meaning: "접근성, 이용 가능성, 이용하기 쉬움",
      synonyms: ["reachability", "availability", "approachability"],
      antonyms: ["inaccessibility", "unavailability"]
    },
    {
      word: "focus",
      partOfSpeech: "v. / n.",
      meaning: "집중하다, 초점, 집중",
      synonyms: ["concentrate", "center", "highlight", "core"],
      antonyms: ["distract", "scatter", "ignore"]
    },
    {
      word: "companion",
      partOfSpeech: "n.",
      meaning: "동반자, 도우미, 동료, 안내서",
      synonyms: ["partner", "guide", "helper", "associate"],
      antonyms: ["stranger", "adversary", "opponent"]
    }
  ];

  const [selectedWord, setSelectedWord] = useState(null);
  const [myVocab, setMyVocab] = useState(() => {
    return JSON.parse(localStorage.getItem('lingo-my-vocab')) || [];
  });

  // 단어장 단어 삭제
  const handleDeleteVocab = (e, wordToDelete) => {
    e.stopPropagation();
    const updated = myVocab.filter(item => item.word.toLowerCase() !== wordToDelete.toLowerCase());
    localStorage.setItem('lingo-my-vocab', JSON.stringify(updated));
    setMyVocab(updated);
  };

  // 실시간 뜻 자동 교정 헬퍼 (기존에 오인되어 잘못 들어온 영어 뜻을 한글로 보정)
  const getCorrectedMeaning = (item) => {
    const cleanWord = item.word.toLowerCase().trim();
    const cleanMeaning = item.meaning ? item.meaning.trim() : '';
    
    // 뜻이 없거나, 뜻에 영어단어가 그대로 들어가 있거나, '학습용 추천 단어'라고 적혀 있는 경우 보정 작동
    if (!cleanMeaning || 
        cleanMeaning.toLowerCase() === cleanWord || 
        cleanMeaning.includes('(학습용 추천 단어)') || 
        cleanMeaning === item.word) {
      return dictMock[cleanWord] || parseDynamicWordMeaning(item.word);
    }
    return item.meaning;
  };

  const cardStyle = (isSelected) => ({
    border: isSelected ? '6px solid var(--color-primary)' : '4px solid var(--color-border)',
    borderRadius: '20px',
    padding: '28px',
    backgroundColor: 'var(--color-bg)',
    cursor: 'pointer',
    transition: 'transform 0.2s, box-shadow 0.2s',
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
    boxShadow: isSelected ? '0 8px 32px rgba(0,102,204,0.15)' : '0 4px 16px rgba(0,0,0,0.05)'
  });

  const chipContainerStyle = {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '12px',
    marginTop: '8px'
  };

  const chipStyle = (bgColor, textColor) => ({
    fontSize: '20px',
    fontWeight: 'bold',
    padding: '8px 16px',
    borderRadius: '30px',
    backgroundColor: bgColor,
    color: textColor,
    border: '2px solid var(--color-border)'
  });

  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      gap: '32px', 
      overflowY: 'auto', 
      height: '100%',
      paddingBottom: '64px'
    }}>
      {/* SECTION 1: ⭐ 나만의 집중 학습 단어장 */}
      <div style={{
        border: '6px solid var(--color-border)',
        borderRadius: '24px',
        padding: '32px 24px',
        backgroundColor: 'var(--color-bg)',
        boxShadow: '0 8px 32px rgba(0,0,0,0.05)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <h3 style={{ fontSize: '32px', fontWeight: '900', color: 'var(--color-primary)' }}>
            ⭐ 나만의 집중 학습 단어장
          </h3>
          <p style={{ fontSize: '20px', opacity: 0.7, marginTop: '8px' }}>
            본문 읽기 중 단어/숙어를 누르거나 드래그하여 추가한 단어 컬렉션입니다.
          </p>
        </div>

        {myVocab.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: '48px 16px',
            border: '4px dashed var(--color-border)',
            borderRadius: '16px',
            backgroundColor: 'var(--color-bg)'
          }}>
            <p style={{ fontSize: '24px', fontWeight: 'bold', opacity: 0.6 }}>
              아직 지문에서 저장한 단어가 없습니다.<br />
              [집중] 탭에서 본문의 단어/숙어를 드래그하거나 터치하여 추가해보세요!
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {myVocab.map((item, idx) => (
              <div
                key={idx}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '24px',
                  border: '4px solid var(--color-border)',
                  borderRadius: '16px',
                  backgroundColor: 'var(--color-bg)',
                  gap: '16px',
                  flexWrap: 'wrap'
                }}
              >
                <div style={{ flex: 1, minWidth: '250px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <h4 style={{ fontSize: `${fontSize}px`, fontWeight: '900', color: 'var(--color-primary)' }}>
                      {item.word}
                    </h4>
                    <span style={{ 
                      fontSize: '14px', 
                      fontWeight: 'bold',
                      color: 'var(--color-text)', 
                      opacity: 0.6,
                      border: '2px solid var(--color-border)',
                      padding: '2px 8px',
                      borderRadius: '12px',
                      backgroundColor: 'var(--color-secondary)'
                    }}>
                      {item.word.includes(' ') ? '이디엄/숙어' : '단어'}
                    </span>
                  </div>
                  
                  {/* 뜻 출력 시 정밀 실시간 교정 적용 */}
                  <p style={{ fontSize: `${fontSize * 0.75}px`, fontWeight: 'bold', marginTop: '8px', color: 'var(--color-text)' }}>
                    뜻: {getCorrectedMeaning(item)}
                  </p>
                  
                  {item.sentence && (
                    <p style={{ fontSize: '18px', opacity: 0.6, marginTop: '8px', wordBreak: 'break-all' }}>
                      문장: {item.sentence}
                    </p>
                  )}
                </div>

                <div style={{ display: 'flex', gap: '12px' }}>
                  {/* 단어 원어민 TTS 낭독 */}
                  <button
                    onClick={() => speakText(item.word)}
                    style={{
                      minWidth: '64px',
                      minHeight: '64px',
                      fontSize: '24px',
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: 'var(--color-secondary)',
                      color: 'var(--color-text)',
                      border: '3px solid var(--color-border)'
                    }}
                    title="발음 듣기"
                  >
                    🔊
                  </button>

                  {/* 단어 삭제 버튼 */}
                  <button
                    onClick={(e) => handleDeleteVocab(e, item.word)}
                    style={{
                      minWidth: '64px',
                      minHeight: '64px',
                      fontSize: '24px',
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: '#ffdddd',
                      color: '#cc0000',
                      border: '3px solid #cc0000'
                    }}
                    title="삭제"
                  >
                    ❌
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECTION 2: 📒 동의어 · 반의어 어휘 카드 */}
      <div style={{ textAlign: 'center', marginTop: '16px' }}>
        <h3 style={{ fontSize: '30px', fontWeight: 'bold' }}>📒 동의어 · 반의어 어휘 카드</h3>
        <p style={{ fontSize: '20px', opacity: 0.7, marginTop: '8px' }}>
          지문의 핵심 어휘를 큼직하게 정리했습니다. 카드를 눌러 발음 및 동의어/반의어를 학습하세요.
        </p>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(100%, 1fr))',
        gap: '24px'
      }}>
        {defaultWords.map((item, idx) => {
          const isSelected = selectedWord === item.word;
          return (
            <div 
              key={idx} 
              style={cardStyle(isSelected)}
              onClick={() => setSelectedWord(isSelected ? null : item.word)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: '16px' }}>
                  <h4 style={{ 
                    fontSize: `${fontSize}px`, 
                    fontWeight: '900', 
                    color: 'var(--color-primary)' 
                  }}>
                    {item.word}
                  </h4>
                  <span style={{ fontSize: '20px', fontStyle: 'italic', opacity: 0.6 }}>
                    {item.partOfSpeech}
                  </span>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      speakText(item.word);
                    }}
                    style={{
                      minWidth: '60px',
                      minHeight: '60px',
                      fontSize: '20px',
                      borderRadius: '50%',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: 'var(--color-secondary)',
                      border: '2px solid var(--color-border)'
                    }}
                    title="발음 듣기"
                  >
                    🔊
                  </button>
                  <span style={{ fontSize: '28px' }}>
                    {isSelected ? '🔼' : '🔽'}
                  </span>
                </div>
              </div>

              <p style={{ 
                fontSize: `${fontSize * 0.75}px`, 
                fontWeight: 'bold',
                lineHeight: '1.4'
              }}>
                뜻: {item.meaning}
              </p>

              {isSelected && (
                <div style={{ 
                  display: 'flex', 
                  flexDirection: 'column', 
                  gap: '20px',
                  paddingTop: '16px',
                  borderTop: '2px solid var(--color-border)',
                  animation: 'fadeIn 0.2s ease'
                }}>
                  <div>
                    <h5 style={{ fontSize: '22px', fontWeight: 'bold', marginBottom: '8px' }}>🔄 뜻이 비슷한 단어 (Synonyms / 동의어)</h5>
                    <div style={chipContainerStyle}>
                      {item.synonyms.map((syn, sIdx) => (
                        <span 
                          key={sIdx} 
                          style={chipStyle('var(--color-bg)', 'var(--color-primary)')}
                        >
                          {syn}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h5 style={{ fontSize: '22px', fontWeight: 'bold', marginBottom: '8px' }}>↔️ 뜻이 반대인 단어 (Antonyms / 반의어)</h5>
                    <div style={chipContainerStyle}>
                      {item.antonyms.map((ant, aIdx) => (
                        <span 
                          key={aIdx} 
                          style={chipStyle('var(--color-secondary)', 'var(--color-text)')}
                        >
                          {ant}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
